# 🗺️ MEGAWALLET ANDROID — MASTER EXECUTION PLAN (v2.0 Domain-Driven)

## 🎯 ULTIMATE GOAL
Complete a production-ready, secure, and performant Android wallet by grouping related services into cohesive, end-to-end phases (0 to 100%), strictly respecting architectural dependencies.

---

## 📊 PHASE OVERVIEW (9 Consolidated Phases)

| Phase | Title | Priority | Dependencies | Core Focus |
|:---:|:---|:---:|:---|:---|
| **1** | Network Foundation & Security Core | P0 | None | BigInt, ApiError, Interceptors, BuildConfig |
| **2** | Web3 Auth & Device Identity | P0 | Phase 1 | Challenge/Verify, Play Integrity Fallback, JWT Storage |
| **3** | Complete Proxy & Core Data (Read Layer) | P0 | Phase 1, 2 | Config Bundle, Balances (Batch), History, Fees, Prices |
| **4** | Gasless & Sponsor Flow (Write Layer) | P0 | Phase 2, 3 | Prepare → Quote → Relay, Strict Error Handling |
| **5** | Real-Time Updates (WS & FCM) | P1 | Phase 2, 3 | WebSocket Auth, Heartbeat, FCM Token, Deduplication |
| **6** | Growth & Engagement System | P2 | Phase 2, 5 | Referral (Init/Claim/Stats), Mystery Box, Gas Credit |
| **7** | Swap Engine Integration | P2 | Phase 3, 4, 5 | Quote, Prepare, Allowance, Execution, TTL Handling |
| **8** | Security Hardening & Settings | P1 | Phase 3, 4 | Secure Wallet Deletion, DIRECT/PROXY Toggle, Global Snackbar |
| **9** | UI Polish & Performance Fixes | P2 | All above | Coil Singleton, Tab Composition, Animations, Shimmer |

---

## 🔷 PHASE 1: Network Foundation & Security Core
**Goal:** Establish the unbreakable rules for all network communication.
**Scope:**
- Register `BigIntegerStringAdapter` globally in `NetworkModule` (ban `Long`/`Double` for raw money).
- Implement `sealed class ApiError` and `ProxyEnvelope` for machine-code error branching.
- Create `AuthInterceptor` (JWT injection), `IdempotencyInterceptor` (UUID for mutations), and secure `HttpLoggingInterceptor` (BASIC in Release).
- Move hardcoded IPs to `BuildConfig`.
**Success Criteria:** All network calls are type-safe, errors are machine-readable, and no sensitive data leaks in logs.

---

## 🔷 PHASE 2: Web3 Auth & Device Identity
**Goal:** Securely identify the user and device without blocking legitimate users.
**Scope:**
- Implement `AuthApiService` (`/challenge`, `/verify`, `/refresh`).
- Create `ResilientDeviceIdProvider`: Attempt Play Integrity; on failure (GMS missing/timeout), generate deterministic hash (`ANDROID_ID` + `Installation UUID`).
- Update `SecureTokenStore` to save JWT and `deviceId`.
- Wire `AuthInterceptor` to read from `SecureTokenStore`.
**Success Criteria:** App can authenticate, receives JWT, and passes `deviceId` to backend. Fallback works seamlessly on non-GMS devices.

---

## 🔷 PHASE 3: Complete Proxy & Core Data (Read Layer)
**Goal:** Fetch ALL wallet data exclusively through the secure backend (0 to 100%).
**Scope:**
- **Dynamic Config:** `ConfigApiService` (`/bundle`, `/version`, `/public-key`) + `ConfigManager` (verify secp256k1 signature, cache).
- **Proxy Endpoints:** Implement `MobileProxyApiService` for Balances (single & batch), Fees, Broadcast, and Status.
- **Unified History:** `POST /api/mobile/v1/history` with polymorphic Gson deserializer (EVM/TRON/BTC) and cursor pagination.
- **Prices:** Switch from direct CoinDesk to `GET /api/v1/prices` (batch up to 50 symbols).
- Wire all into `ProxyChainDataSource` implementing `IChainDataSource`.
**Success Criteria:** App loads config dynamically, fetches multi-network balances/history via Proxy, and displays backend prices. DIRECT mode remains as a fallback.

---

## 🔷 PHASE 4: Gasless & Sponsor Flow (Write Layer)
**Goal:** Execute secure, idempotent, gasless transactions.
**Scope:**
- Update `EvmGaslessCoordinator` and `TronGaslessCoordinator` to enforce: `prepare` → `quote` → `relay`.
- Pass `feeFundingSource` (`GAS_CREDIT`, `WALLET`, `SPONSOR`) explicitly.
- **CRITICAL:** Implement strict `ApiError` branching. NO auto-fallback to WALLET on `RACE_CONDITION_LOCK` or `INSUFFICIENT_GAS_CREDIT`. Propagate to UI.
- Ensure all DTOs use `BigInteger` for amounts/nonces.
**Success Criteria:** Gasless transfers work end-to-end. Errors are surfaced correctly without silent, dangerous fallbacks.

---

## 🔷 PHASE 5: Real-Time Updates (WS & FCM)
**Goal:** Provide instant feedback for transaction status and balance changes.
**Scope:**
- **WebSocket:** Fix `NotificationSocketManager` to connect to `/ws` with JWT (header/query). Implement 30s heartbeat and exponential backoff reconnection.
- **FCM:** Register/unregister tokens via `/api/notifications/devices`.
- **Deduplication:** Implement logic to ignore FCM pushes if the same `eventId` was just received via WebSocket.
**Success Criteria:** App receives real-time `tx.status.changed` and `balance.updated` events. Reconnects automatically. No duplicate notifications.

---

## 🔷 PHASE 6: Growth & Engagement System
**Goal:** Implement referral tracking and mystery box rewards.
**Scope:**
- **Referral:** `POST /api/referral/device/init` (at install), `/claim`, `/code`, and `GET /api/v1/growth/referral/stats`.
- **Mystery Box:** `GET /boxes/odds`, `/boxes`, and `POST /boxes/:id/open` (requires device JWT). Handle `409` and `429` errors.
- **Gas Credit:** `GET /api/v1/growth/gas-credit/balance` integration.
**Success Criteria:** Users can claim referrals, view stats, and open mystery boxes. Device-bound rewards work correctly.

---

## 🔷 PHASE 7: Swap Engine Integration
**Goal:** Multi-route token swapping with strict TTL and simulation.
**Scope:**
- `SwapApiService`: `/providers`, `/quote` (15s TTL), `/prepare`.
- Handle allowance pipeline and `SWAP_SIMULATION_FAILED` (422).
- Integrate with Gasless relay if applicable.
**Success Criteria:** Users can get quotes, see countdown timers, and execute swaps safely.

---

## 🔷 PHASE 8: Security Hardening & Settings
**Goal:** Fix critical security gaps and provide user control.
**Scope:**
- **Secure Deletion (KAN-18):** Update `WalletRepositoryImpl.deleteWallet` to use `secureStorage.remove()` instead of blanking. Clear `ActiveWalletManager` cache.
- **Settings (KAN-19):** Build Settings UI with DIRECT/PROXY toggle, persisting via `IUserPreferencesRepository`.
- **Global Snackbar (KAN-20/21):** Map `ApiError` codes to user-friendly Farsi/English messages.
**Success Criteria:** Deleted wallets leave zero trace. Users can switch transport modes. Errors are displayed gracefully.

---

## 🔷 PHASE 9: UI Polish & Performance Fixes
**Goal:** Eliminate jank and optimize Compose rendering.
**Scope:**
- **KAN-NEW-05:** Use singleton `LocalContext.current.imageLoader` in history lists.
- **KAN-NEW-06:** Gate inactive tabs (HISTORY) with `if` instead of `alpha` fading.
- **KAN-NEW-08:** Pause `FloatingShapesBackground` infinite animations when off-screen.
- Add Shimmer loading states and proper empty states.
**Success Criteria:** Smooth 60fps scrolling, no unnecessary recompositions, premium feel.

---

## 🚦 EXECUTION STRATEGY
1. **One Phase at a Time:** Do not start Phase N+1 until Phase N is 100% complete, wired, and tested.
2. **End-to-End Wiring:** Every new API method MUST have: DTO → ApiService → Domain Interface → Repository Impl → Hilt DI Binding. No dangling code.
3. **NO CODE IN CHAT:** Use `write_file` / `edit_file` tools directly. Reply ONLY with the list of modified files.
4. **Update This File:** After completing a phase, change its status to `[x] COMPLETE`.

---

## 📝 CURRENT STATUS
- [ ] Phase 1: Network Foundation & Security Core
- [ ] Phase 2: Web3 Auth & Device Identity
- [ ] Phase 3: Complete Proxy & Core Data (Read Layer)
- [ ] Phase 4: Gasless & Sponsor Flow (Write Layer)
- [ ] Phase 5: Real-Time Updates (WS & FCM)
- [ ] Phase 6: Growth & Engagement System
- [ ] Phase 7: Swap Engine Integration
- [ ] Phase 8: Security Hardening & Settings
- [ ] Phase 9: UI Polish & Performance Fixes

**Next Action:** Execute Phase 1 & 2 Foundation.