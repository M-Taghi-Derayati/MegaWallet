# MegaWallet — Android Architecture

> Canonical architecture reference for the MegaWallet Android client.
> Discovery pass — read-only. Source of truth: code under `app/`, `core/`, `data/`, `domain/`, `common_ui/`.
> Last discovered: 2026-05-31.

---

## 1. Project Overview

**Purpose.** Non-custodial multi-chain crypto wallet. Generates/imports wallets, derives per-chain keys, shows balances and history, and sends transfers — either **directly** (user pays native gas) or **gasless** (user signs EIP-712 / Permit2 off-chain; the MegaWallet relayer backend submits the on-chain transaction and takes a fee in the transferred token). This client is the counterpart to the `megaWallet_server` relayer.

**Architecture style.** Clean Architecture + MVVM, multi-module Gradle, Hilt DI, Jetpack Compose UI with unidirectional state (`StateFlow<UiState>`). Domain layer is framework-light and defines interfaces (`interfaceRepository/`); `data` provides implementations; Hilt `@Binds` wires interface → impl.

**Module count.** 5 Gradle modules: `app`, `common_ui`, `data`, `domain`, `core` (see `settings.gradle.kts`).

**Dependency direction.** Strictly inward toward `domain`:
`app` → (`data`, `domain`, `core`, `common_ui`); `data` → (`domain`, `core`); `core` → (`domain`); `domain` → (none internal); `common_ui` → (none internal). No cycles.

**Toolchain.** AGP 8.9.3, Kotlin 2.1.10, Java 17, compileSdk 36, minSdk 26, targetSdk 36, Compose BOM 2026.01.01, Hilt 2.56.2 + KSP. No product flavors; `debug` and `release` build types only.

---

## 2. Module Inventory

| Module | Responsibility | Depends On |
|---|---|---|
| `app` (`com.mtd.megawallet`) | Application class, two Compose Activities, all ViewModels, Compose screens/components, navigation graphs, biometric helper. The composition root for UI. | `data`, `domain`, `core`, `common_ui` |
| `domain` (`com.mtd.domain`) | Pure business contracts: models (`model/`), repository interfaces (`interfaceRepository/`), use cases (`usecase/`), app-lock security (`security/AppLockManager`, `PasscodeCrypto`), error mapping. No Android/blockchain SDK deps beyond Hilt + coroutines. | — |
| `core` (`com.mtd.core`) | Crypto & blockchain engine: AndroidKeystore + AES-GCM, key derivation, `BlockchainNetwork` impls (EVM/Tron/Bitcoin/UTXO), registries, ABI encoders, EIP-712 signer, cross-cutting managers (network, cache, error, coroutine, navigation). | `domain` |
| `data` (`com.mtd.data`) | Repository implementations, chain data sources, Retrofit services + DTOs, gasless coordinators, Google Drive backup, sockets, DI modules. | `domain`, `core` |
| `common_ui` (`com.mtd.common_ui`) | Standalone UI toolkit: Compose theme, Coil, QR generation, slide-to-act, splash. No business deps. | — |

---

## 3. Dependency Graph

```
                         ┌─────────────┐
                         │     app     │  (Compose UI, ViewModels, Activities)
                         └──────┬──────┘
            ┌───────────────────┼───────────────────┬──────────────┐
            v                   v                   v              v
       ┌─────────┐         ┌─────────┐         ┌─────────┐   ┌────────────┐
       │  data   │────────>│  core   │────────>│ domain  │   │ common_ui  │
       └────┬────┘         └────┬────┘         └─────────┘   └────────────┘
            │                   │                   ^
            └───────────────────┴───────────────────┘
                    (data → domain, core → domain)

domain  : depends on nothing internal (contracts + models + use cases)
common_ui: depends on nothing internal (pure UI toolkit)

DI wiring (Hilt SingletonComponent):
  DataModule  includes  NetworkModule + CryptoModule
  CryptoModule includes ManagerModule
  → one object graph; @Binds maps domain interfaces to data/core impls.
```

---

## 4. Data Flow

General pattern: **Compose screen → ViewModel (StateFlow UiState) → UseCase → Repository interface → Impl → DataSource/Service → Network/Blockchain**. ViewModels are `@HiltViewModel`, extend `BaseViewModel(errorManager)`, inject use cases + domain catalogs (`IAssetCatalog`, `INetworkCatalog`, `IAppEventBus`, `IAppCacheStore`).

**4.1 App start / unlock**
```
WelcomeActivityCompose (LAUNCHER)
  → SplashScreen → WelcomeViewModel.hasWallet()  (HasWalletUseCase → IWalletRepository)
      has wallet → start MainActivityCompose
      none       → OnboardingScreen → create / import
MainActivityCompose
  → AppLockViewModel.initialize()  (AppLockManager.isPasscodeConfigured → IUserPreferencesRepository)
  → if locked: blur + biometric (BiometricAuthHelper) or PasscodeKeypadSheet → unlockWithPasscode
```

**4.2 Create / import wallet**
```
CreateWalletViewModel / WalletImportViewModel
  → WalletManagement/WalletImport UseCases → IWalletRepository (WalletRepositoryImpl)
  → MnemonicHelper.generateMnemonic()  (or validate mnemonic / private key)
  → SecureStorage.putEncrypted("wallet_secret_<id>", secret)   [AES-GCM, AndroidKeystore]
  → KeyManager.generateWalletKeysFromMnemonic(secret)          [per-network derivation]
  → ActiveWalletManager.unlockWallet(wallet, secret)           [in-memory Credentials cache]
```

**4.3 Home balances**
```
HomeViewModel
  → ObserveActiveWalletUseCase / GetBalancesForMultipleWalletsUseCase
  → IWalletRepository → ChainDataSourceFactory.create(chainId) → IChainDataSource.getBalanceAssets()
  → EvmDataSource / TronDataSource / BitcoinDataSource (DIRECT) over RPC/explorer APIs
  → prices: GetLatestAssetPricesUseCase → IMarketDataRepository (CoinDesk) ; USD→IRR via Wallex
  → cached via IAppCacheStore (CacheManager); refresh signalled over IAppEventBus
```

**4.4 Direct (self-paid) transfer**
```
SendViewModel → SendAsset UseCases → IUnifiedTransferCoordinator.sendNormal(UnifiedTransferRequest)
  → resolve NetworkType → build TransactionParams (Evm/Tvm/Utxo, ABI-encode token transfer)
  → IWalletRepository.sendTransaction(params)
      → KeyManager.getCredentialsForChain(chainId)  [requires unlocked wallet]
      → ChainDataSourceFactory.create(chainId).sendTransaction(params, privateKey)
      → broadcast to chain
```

**4.5 Gasless transfer (relayer backend)** — headline flow, mirrors the server lifecycle
```
SendViewModel → IUnifiedTransferCoordinator → Evm/TronGaslessCoordinator → Gasless repo → GaslessApiGateway → GaslessApiService
  1. checkEligibility   POST /api/{chain}/eligibility
  2. prepareSession     GET  /api/{chain}/prepare/{user}      → nonce, chainId, relayerContract, treasury, prepareToken
     (EVM) getAllowance via web3j ethCall(allowance) with RPC failover
  3. previewQuote/quote POST /api/{chain}/quote               → canonicalParams, fee, displayPolicy, smartFee
  4. if needsApprove: buildApproveTransaction (ERC20 approve to Permit2) → sent as a normal tx,
        or sponsor:   POST /api/{chain}/sponsor-approve       (relayer funds/gift the approve)
  5. signAndSubmit: TypedDataSigner.signTypedDataHex twice (EIP-712):
        - Permit2  "PermitTransferFrom" (domain: Permit2)
        - MegaRelayer "MegaTransfer"    (domain: MegaRelayer v1.0.0)
     relay  POST /api/{chain}/relay  (x-idempotency-key)      → queued tx id
  6. pollUntilFinal     GET  /api/{chain}/tx/{id}             → SUCCESS / FAILED / TIMEOUT
     PendingGaslessTxStore persists queued txs until final.
```

**4.6 Cloud backup / recovery**
```
backup  : wallet JSON → PasswordBasedCipher.encrypt(password) [PBKDF2] → GoogleDriveDataSource.uploadBackup → Drive appDataFolder/megawallet_backup.dat
restore : GoogleDriveDataSource.downloadBackup → PasswordBasedCipher.decrypt(password) → import wallet
auth    : GoogleAuthManager (IAuthManager) → OAuth auth code → Drive credential
```

---

## 5. Security Architecture

**Key storage.**
- Per-wallet secret (BIP-39 mnemonic *or* raw private key) and wallet metadata list are stored in `SharedPreferences("secure_prefs")` as Base64 of AES-GCM ciphertext. Keys: `wallet_secret_<id>`, `wallets_metadata_list`, `active_wallet_id`, `custom_rpc_<chainId>` (`SecureStorage.kt`, `WalletRepositoryImpl.kt`).
- Private keys are **never persisted derived**; they are re-derived from the secret on unlock and held in-memory only (`KeyManager.credentialsCache`, `ConcurrentHashMap<chainId, Credentials>`), cleared on `clearCache()` / wallet lock.

**Keystore usage.** `KeyStoreManager` creates/loads a single AES-256 key (alias `mega_wallet_master_key`) in `AndroidKeyStore`, GCM, no padding. `AESGCMCipher` prepends the Keystore-generated 12-byte IV; 128-bit auth tag.

**Encryption primitives.**
- At-rest secrets: AES-256-GCM via Keystore key (`AESGCMCipher`).
- Cloud backup blob: `PasswordBasedCipher` — AES-256-GCM, key derived by PBKDF2WithHmacSHA256 (65,536 iters, 16-byte salt, 12-byte IV), versioned (`version|salt|iv|ciphertext`).
- App passcode: `PasscodeCrypto` — PBKDF2WithHmacSHA256 (120,000 iters, 256-bit), random salt, constant-time compare (`MessageDigest.isEqual`). Hash+salt stored via `IUserPreferencesRepository`.

**App lock.** `AppLockManager` (domain): 6-digit passcode, foreground/background timeout auto-lock (default 30 s), max 5 failed attempts → 30 s lockout. Optional biometric unlock (`BiometricAuthHelper`, `androidx.biometric`). `MainActivityCompose` renders a blur + scrim overlay and biometric/passcode sheets while locked; also gates `SENSITIVE_ACTION` auth.

**Backup flow.** User sets a backup password → wallet data encrypted client-side → uploaded to Google Drive **appDataFolder** (app-private Drive space), filename `megawallet_backup.dat`.

**Recovery flow.** Google sign-in → list/download backup → decrypt with user password (`AEADBadTagException` ⇒ wrong password) → re-import into `WalletRepositoryImpl`.

---

## 6. Blockchain Architecture

Abstraction: `core/network/BlockchainNetwork` interface; concrete `GenericEvmNetwork`, `TronNetwork`, `BitcoinNetwork`. Built by `NetworkFactory` strategies and indexed in `BlockchainRegistry` (loaded from `core/src/main/assets/networks.json`; tokens from `assets.json`). `NetworkType` ∈ {`EVM`, `TVM` (Tron), `BITCOIN`, `UTXO` (LTC/DOGE)}. Runtime data access via `IChainDataSource` chosen by `ChainDataSourceFactory` per connection mode (`DIRECT` vs `PROXY`).

**EVM (Ethereum, BSC, …)**
- Wallet gen: BIP-39 seed → BIP-32 derive `m/44'/60'/0'/0/0` (web3j `Bip32ECKeyPair`, `EvmKeyDerivation`).
- Signing: normal tx via web3j `Credentials`; gasless via EIP-712 typed data (`TypedDataSigner`) — Permit2 `PermitTransferFrom` + `MegaTransfer`.
- Balance/history: `EvmDataSource` over JSON-RPC (web3j) + Blockscout/BSCscan APIs; `EvmGaslessRepositoryImpl` does `ethCall` (allowance/treasury) with multi-RPC failover and a per-URL `Web3j` cache.
- Broadcast: direct `eth_sendRawTransaction` or gasless relay through backend.

**TRON (TVM)**
- `TronNetwork` derivation; `TronDataSource` + `TronService` against TronGrid-style APIs; `TronAbiEncoder`, `TronAddressConverter` (hex↔Base58).
- Gasless: `TronGaslessCoordinator`; supports sponsor-approve (energy/bandwidth) flow with `quote/approve`.
- Broadcast: direct or gasless relay.

**Bitcoin / UTXO (BTC, LTC, DOGE + testnets)**
- `BitcoinNetwork` via bitcoinj + bitcoin-kmp (secp256k1 JNI); params from `UtxoNetworkParametersResolver`.
- `BitcoinDataSource` + `UtxoApiService`/`BTCApiService` for UTXOs, fee rate, broadcast. No gasless (token transfer unsupported on UTXO).

> Note: `BlockchainRegistry.loadNetworksFromAssets` currently filters `config.isTestnet == true`, so only **testnet** networks are registered at runtime.

---

## 7. External Services

| Service | Where | Notes |
|---|---|---|
| MegaWallet gasless relayer backend | `NetworkModule.serverIp = "2.27.43.141"`, `http://<ip>:3000/` | `GaslessApiService` (tokens/eligibility/prepare/quote/relay/tx/sponsor-approve). **Plain HTTP, hardcoded IP.** |
| CoinDesk price API | `https://data-api.coindesk.com/` | token USD prices (`CoinDetailApiService`, `MarketDataRepositoryImpl`). |
| Wallex | `https://api.wallex.ir/` | USDT/IRR rate (`USDTApiService`). |
| Google Drive | `GoogleDriveDataSource` | encrypted backup in Drive appDataFolder. |
| Google Sign-In / OAuth | `GoogleAuthManager`, Google API client libs | auth-code exchange for Drive. **Client IDs + OAuth client secret are hardcoded in `GoogleDriveDataSource`.** |
| Blockchain RPCs / explorers | per-network from `networks.json` | EVM JSON-RPC, Blockscout, BSCscan, TronGrid, UTXO APIs. |
| WebSocket (socket.io) | `SocketModule`, `NotificationSocketManager`, `IWebSocketClient` | notifications / realtime; ping-keepalive OkHttp clients. |
| Image loading | Coil (`MegaWalletApplication : ImageLoaderFactory`) | SVG decoder, 20% mem / 30 MB disk cache. |

> Firebase: version refs (`firebase-auth`, `firebase_plugin`) appear in `libs.versions.toml` but the plugin is **not applied** and no Firebase deps are wired in module `dependencies` — effectively unused.

---

## 8. Build & Runtime Configuration

- **Modules / plugins.** Root applies Android+Kotlin+KSP+kapt+Hilt+nav-safeargs aliases; `app` adds Compose compiler. `common_ui` is Compose-only (no Hilt). Library modules use `android.library`.
- **Build types.** `debug` (`applicationIdSuffix .debug`, `versionNameSuffix -debug`, debuggable); `release` (`isMinifyEnabled` + `isShrinkResources` + ProGuard `proguard-rules.pro`). **No product flavors.** Library modules set `isMinifyEnabled=true` but have proguard blocks commented out.
- **Signing.** `release` signing pulled from Gradle properties `MEGAWALLET_RELEASE_STORE_FILE/STORE_PASSWORD/KEY_ALIAS/KEY_PASSWORD`; signing applied only if all are present (v1+v2 signing).
- **Dependency resolution.** Root `subprojects` block force-aligns all `org.bouncycastle:bcprov*` to `bcprov-jdk18on:1.73` (resolves Web3j/Bitcoin duplicate-class conflict). Repos include jitpack + `maven.google.com` with `isAllowInsecureProtocol=true`.
- **Manifest / app config.** `MegaWalletApplication : MultiDexApplication, ImageLoaderFactory` (`@HiltAndroidApp`); Timber logging (DebugTree in debug, INFO+ in release). Launcher = `WelcomeActivityCompose`; secondary `MainActivityCompose` (`FragmentActivity`, for biometric). Permissions: INTERNET, ACCESS_NETWORK_STATE, POST_NOTIFICATIONS. `android:allowBackup="true"` with `backup_rules.xml` / `data_extraction_rules.xml`; `networkSecurityConfig` declared.
- **Config files.** `core/src/main/assets/networks.json` (chain configs), `core/src/main/assets/assets.json` (token catalog), `gradle/libs.versions.toml` (version catalog).
- **Networking.** Single shared `OkHttpClient` (35 s timeouts) + `HttpLoggingInterceptor` at `BODY` level (redacts only `Authorization`/`Cookie`); `NetworkConnectionInterceptor`; separate ping-keepalive clients for sockets. Retrofit with Scalars + Gson converters; custom `TransactionRecordAdapter`.

---

## 9. Risks & Unknown Areas (findings only)

- **Hardcoded Google OAuth client secret and client IDs** in `GoogleDriveDataSource.kt` (`GOCSPX-…`, two client IDs) committed to source.
- **Gasless backend over plaintext HTTP to a hardcoded IP** (`http://2.27.43.141:3000/` in `NetworkModule`); no TLS, no host-based config; cleartext likely whitelisted via `network_security_config`.
- **Keystore master key is not bound to user authentication** (no `setUserAuthenticationRequired`/StrongBox). At-rest wallet secrets are decryptable by the app process without app-lock; app-lock is enforced only in the UI layer.
- **`HttpLoggingInterceptor` at `BODY`** is installed on the shared client; request/response bodies (including relay payloads, addresses, signatures) may be logged. Release routes Timber to logcat at INFO+.
- **`android:allowBackup="true"`** — depends on `backup_rules.xml` / `data_extraction_rules.xml` contents (not yet audited) to ensure `secure_prefs`/`secure_prefs` exclusion; secrets are encrypted but the Keystore key is non-exportable, so cloud/adb backup of ciphertext would be undecryptable elsewhere (needs confirmation).
- **Only testnet networks are registered** (`loadNetworksFromAssets` filters `isTestnet == true`) — mainnet path is currently inactive; intent vs. leftover unknown.
- **Legacy wallet migration writes empty strings** instead of removing legacy keys (`migrateLegacyWalletIfNeeded`); residual encrypted blanks remain.
- **`PROXY` connection mode is stubbed** — `ProxyChainDataSource` is registered but `unsupportedModeException` text suggests it is "not configured yet"; behavior under PROXY unverified.
- **Backup `password` strength is unconstrained at this layer** — only correctness of decryption is checked; policy/UX enforcement not audited.
- **Unaudited areas (not yet read):** `MainScreen` inner navigation and the many `viewmodel/news/*` ViewModels; `SocketModule`/`NotificationSocketManager` auth; `TronGaslessCoordinator` / `TronDataSource` specifics; `network_security_config.xml`, `backup_rules.xml`, `proguard-rules.pro`; `ProxyChainDataSource`; `RealtimeEventBus`-equivalent on client; the full `assets/networks.json` contents.
```
