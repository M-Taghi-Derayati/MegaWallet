\# 🚀 CURRENT PROJECT STATUS \& NEXT ACTION



\## ✅ COMPLETED (Do NOT redo these)

\- Phase 1: Network Foundation (BigInteger adapter, ApiError taxonomy, Auth/Idempotency interceptors, secure logging, real ProxyChainDataSource).

\- Phase 2: Core Wallet (Polymorphic History DTOs with Gson deserializer, Batch Balances endpoint, cursor pagination).



\## 🎯 ACTIVE TASK: PHASE 3 (Auth, Config, and Transaction Execution)

You must execute the following micro-steps sequentially using your file tools:



1\. \*\*Micro-step 3.1: Dynamic Config \& Auth\*\*

&#x20;  - Create `ConfigApiService` (`GET /api/v1/config/bundle`, `/version`, `/public-key`).

&#x20;  - Create `AuthApiService` (`POST /api/auth/challenge`, `/verify`, `/refresh`).

&#x20;  - Update `SecureTokenStore` to save JWT and `deviceId` upon `/verify`.



2\. \*\*Micro-step 3.2: Gasless Relay Flow\*\*

&#x20;  - Update `GaslessApiGateway` to enforce: `prepare` → `quote` (handle 400/409 via `ApiError`) → `relay` (with `X-Idempotency-Key`).

&#x20;  - Ensure all DTO amounts are `BigInteger`.



3\. \*\*Micro-step 3.3: Standard Broadcast \& Polling\*\*

&#x20;  - Add to `MobileProxyApiService`: `POST /api/mobile/v1/networks/{id}/transactions/broadcast` and `GET /.../{txId}/status`.

&#x20;  - Create `TransactionStatusRepository` for polling/WS backfill.



\## 🚦 EXECUTION

Start with Micro-step 3.1. Apply changes directly to files. Reply ONLY with the list of modified file paths.

