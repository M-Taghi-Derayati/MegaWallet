# MegaWallet Android — UI / Compose Performance Audit

**Mode:** Discovery only (code read, no edits). Baseline: `android-performance-state.md`, `android-audit-state.md`, `android-architecture.md`.
**Date:** 2026-05-31. **Files inspected:** MainScreen, WalletScreen, TransactionHistoryScreen, AnimatedCounter, FloatingShapesBackground, AnimatedMainNavIcon, HomeViewModel (excerpt), MainActivityCompose.
**Confidence:** 🔴 Confirmed (code evidence) · 🟠 Likely · 🟡 Possible.

---

## 1. Confirmed UI Bottlenecks

| # | Finding | Evidence | Conf. |
|---|---|---|---|
| C1 | **New Coil `ImageLoader` created per history row** instead of the app singleton — duplicate caches, repeated decode setup. | `TransactionHistoryScreen.kt:495` `val imageLoader = remember { coil.ImageLoader(context) }` (per `HistoryNetworkIcon`, used in each list row & sheet row). Contrast `WalletScreen.kt:363` which correctly uses `LocalContext.current.imageLoader`. | 🔴 |
| C2 | **Inactive tabs stay composed.** WALLET and HISTORY layers are always composed (alpha-faded); only EXPLORE is gated by `if`. History screen + its flows/effects run while user is on Wallet. | `MainScreen.kt:424-448` (`MainTabLayer` called unconditionally for WALLET & HISTORY), `:450` (EXPLORE gated). | 🔴 |
| C3 | **Duplicate `homeViewModel.uiState` collection + duplicate price-sync effect.** Same Success state triggers `syncAssetPricesFromHomeAssets` from two places. | `MainScreen.kt:235-238` and `TransactionHistoryScreen.kt:118-122`. | 🔴 |
| C4 | **Eager ViewModel creation for not-yet-shown UI.** `createWalletViewModel` + `historyViewModel` built at dashboard entry regardless of overlay/tab visibility. | `MainScreen.kt:173-174` (`hiltViewModel()` in `MainDashboardContent`). | 🔴 |
| C5 | **72dp animated app-lock blur** (full-screen RenderEffect). Already tracked; mitigated to 24dp this session. | perf-state §2; `MainActivityCompose` (KAN-NEW-02). | 🔴 |
| C6 | **Six concurrent infinite animations** drive continuous Canvas redraw while the background is visible. | `FloatingShapesBackground.kt:56-116` (rotateFast/Medium/Slow, diamond, ripple, lock via `rememberInfiniteTransition`). | 🔴 |

## 2. Likely UI Bottlenecks

| # | Finding | Evidence | Conf. |
|---|---|---|---|
| L1 | **`AnimatedCounter` per-digit `AnimatedContent` storm** in list rows; two counters per asset (amount + value). On balance refresh many digit-level `AnimatedContent` animate at once. | `AnimatedCounter.kt:204-265` (per-digit path); used twice per row `WalletScreen.kt:507, 560`. | 🟠 |
| L2 | **Per-row `onGloballyPositioned` bounds capture** for every asset row (morph animation source). | `WalletScreen.kt:219-221` inside `items(...)`. | 🟠 |
| L3 | **Seven overlay layers retained in composition** via boolean `AnimatedVisibility` (Send/Receive/MultiWallet/Import/Create/AssetDetail/BottomSheet) — large always-present tree. | `MainScreen.kt:482-641`. | 🟠 |
| L4 | **Three custom animated nav icons**, each declaring ~8-10 `animateFloatAsState`, all present in the bottom bar; all animate on every tab switch. | `AnimatedMainNavIcon.kt:202-221, 314-347, 471-507`. | 🟠 |
| L5 | **AssetDetail content retained after close** via `lastSelectedId` fallback (`displayId`). | `MainScreen.kt:502-514`. | 🟡 |

## 3. Compose Architecture Smells

- **God-composable:** `MainDashboardContent` (~480 lines) owns ~10 boolean UI states + Rect morph animation + 7 overlays in one recomposition scope (`MainScreen.kt:159-643`).
- **Cross-ViewModel coupling:** `homeViewModel` is threaded into history/send/asset-detail; a single home emission can recompose multiple subtrees and re-run sync effects (C3).
- **Visibility via alpha, not composition:** offscreen tabs kept alive through `graphicsLayer{alpha}` rather than being removed from the tree (C2, `MainScreen.kt:645-667`).
- **Dead tab interaction:** token/collectible tab `onClick` is commented out — `WalletScreen.kt:166` `/* viewModel.onTabSelected(index) */ //todo`.
- **Positive signals (not defects):** lists use stable `key`s (`WalletScreen.kt:216`, `TransactionHistoryScreen.kt:186`), `derivedStateOf` for grouped history rows (`:97-110`), `animateItem` placement, `remember`-cached `Path`s in icons, and a CONFLATED `uiUpdateChannel` throttle in `HomeViewModel` (`:98-113`) explicitly preventing recomposition storms.

## 4. Navigation Performance Risks

- **Two-activity model** (Welcome→Main) → full Activity recreation + 400-500 ms transitions on first entry (architecture state; `MainActivityCompose`). 🟡
- **Overlays are in-place boolean states, not nav destinations** → all retained simultaneously; back handled by a manual `BackHandler` chain (`MainScreen.kt:247-263`). Increases retained tree size. 🟠
- **`hiltViewModel()` default params vs passed instances:** `TransactionHistoryScreen(viewModel = hiltViewModel(), homeViewModel = hiltViewModel())` defaults would create separate VMs if ever used standalone; here explicit instances are passed, so no duplication in the main path. 🟡

## 5. Animation Risks

- **Continuous infinite animations:** 6 in `FloatingShapesBackground` (C6); plus animated blur (C5). Run while their host screen is visible. 🔴
- **Per-digit `AnimatedContent` churn** in `AnimatedCounter` during frequent balance/price updates (L1). 🟠
- **Staggered multi-`animateFloatAsState` nav icons** all fire on tab change (L4). 🟠
- **Concurrent spring+tween morph** in MainScreen: `Animatable<Rect>` spring + `cornerRadius` spring + `containerAlpha`/`backgroundProgress` tween simultaneously (`MainScreen.kt:195-208, 322-349, 470-480`). 🟠

## 6. Memory Risks

- **Multiple Coil `ImageLoader` instances** (C1) → parallel memory/disk caches beyond the app singleton. 🔴
- **Offscreen tab UIs retained** (C2) keep their `collectAsState` subscriptions and flows active. 🟠
- **Retained detail content** after navigation-back via `lastSelectedId` (L5). 🟡
- **`HomeViewModel` retains `fullRawAssets` (mutable) + per-asset cache map**; bounded by asset count, mitigated by conflated channel (not a leak). 🟡
- No image down-sampling configuration observed at call sites (relies on Coil defaults); oversized-decode risk is **UNKNOWN** (icon sizes are small/local). ⚪

## 7. Recommended Jira Tickets

| Proposed | Summary | Maps to / Priority | Source |
|---|---|---|---|
| KAN-NEW-02 | App-lock blur radius (mitigated 72→24dp this session) | existing, P2 | C5 |
| KAN-NEW-05 *(proposed)* | Use singleton Coil `ImageLoader` in `HistoryNetworkIcon` | new, P2 | C1 |
| KAN-NEW-06 *(proposed)* | Stop composing inactive tabs (gate HISTORY like EXPLORE) | new, P2 | C2 |
| KAN-5 | Deduplicate `homeViewModel.uiState` price-sync effects; redundant collectors | existing (ViewModel logic), P1 | C3 |
| KAN-NEW-07 *(proposed)* | Lazily instantiate overlay ViewModels/screens in `MainDashboardContent` | new, P2 | C4, L3 |
| KAN-NEW-08 *(proposed)* | Pause/limit `FloatingShapesBackground` infinite animations when off-screen | new, P3 | C6 |
| KAN-NEW-09 *(proposed)* | Review `AnimatedCounter` cost inside lists (cap per-digit animation) | new, P3 | L1 |

> Discovery only — no fixes applied. `KAN-NEW-05..09` are **proposals** for the backlog owner, not created tickets. Runtime profiling (frame timing / `layoutinspector` / `tracing`) is required to quantify C2, C6, L1–L4 before prioritization.
```
