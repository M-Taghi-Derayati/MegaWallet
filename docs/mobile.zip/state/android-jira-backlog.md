\# MegaWallet Android Master Backlog (Jira Synced + Security Audited)



This backlog serves as the single source of truth for the Android development lifecycle. It integrates raw data exported from `Jira (1).csv` alongside newly injected engineering tasks derived from critical runtime, security, and performance audits.



\---



\## 🟥 Epic: Core Security \& Cryptography Layer

Tasks dedicated to securing data-at-rest, protecting the wallet state, and ensuring zero-leakage policies for critical cryptographic primitives.



| Key | Summary | Priority | Status | Description |

| :--- | :--- | :--- | :--- | :--- |

| \*\*KAN-17\*\* | \[P1] Fix create/import wallet hierarchy and flow conflicts | High (P1) | To Do | Resolve edge cases during key generation and phrase import state mismatches. |

| \*\*KAN-18\*\* | \[P1] Fix wallet deletion flow | High (P1) | To Do | Complete clearing of local databases and secured shared preferences on user deletion request. |

| \*\*KAN-NEW-01\*\* | \[P1] Secure KeyManager singleton memory footprint | High (P1) | To Do | Ensure raw byte credentials and seeds are zeroed-out/swapped out of RAM immediately after cryptographic signatures to guarantee a Zero-Leakage policy. |

| \*\*KAN-NEW-02\*\* | \[P2] Replace 72dp App-Lock Compose Blur Overlays | Medium (P2) | To Do | Optimize Jetpack Compose blur radius causing visible frame drops on mid-range Android devices during lock-screen states. |



\---



\## 🌐 Epic: Transport Mode Infrastructure (Direct vs. Proxy)

The primary architectural shift: creating a clean toggle between public RPC nodes and the unified MegaWallet Relayer Backend API.



| Key | Summary | Priority | Status | Description |

| :--- | :--- | :--- | :--- | :--- |

| \*\*KAN-4\*\* | Clean Architecture migration and blockchain proxy infrastructure | High (P1) | To Do | Refactor networking primitives into clean data layers capable of handling plural transport protocols. |

| \*\*KAN-6\*\* | \[P1] Finalize reusable cache and event abstractions | High (P1) | To Do | Deliver underlying repository caching rules before implementing live data providers. |

| \*\*KAN-7\*\* | \[P1] Design blockchain connection mode abstraction | High (P1) | To Do | Formulate the polymorphic interfaces that decouple UI ViewModels from knowing where data originates. |

| \*\*KAN-8\*\* | \[P1] Implement proxy-backed chain data sources | High (P1) | To Do | Write network implementations that feed off unified backend proxy routes instead of public RPCs. |

| \*\*KAN-9\*\* | \[P1] Add runtime config for direct/proxy blockchain mode | High (P1) | To Do | Code the core Local Config flag that switches underlying repository behavior dynamically. |

| \*\*KAN-10\*\* | \[P1] Add proxy API contracts for balance, fee, history, and send | High (P1) | To Do | Integrate Retrofit/Ktor model definitions corresponding to the new backend endpoints. |

| \*\*KAN-11\*\* | \[P1] Preserve existing direct blockchain datasource behavior | High (P1) | To Do | Guardrail task to ensure Web3j/TronWeb primitives stay active and reliable when Proxy mode is OFF. |

| \*\*KAN-12\*\* | \[P1] Verify upper layers remain unaware of blockchain transport mode | High (P1) | To Do | Run validation checks ensuring ViewModels and Compose states do not crash or alter layout when switching modes. |

| \*\*KAN-13\*\* | \[P1] Fix gasless flow and test with backend | High (P1) | To Do | End-to-end integration testing of Permit/Sponsor payloads with the MegaWallet relayer service. |

| \*\*KAN-19\*\* | \[P2] Add direct/proxy blockchain mode selection in settings | Medium (P2) | To Do | Add a debug/production UI switch within user settings to swap transport layers cleanly at runtime. |

| \*\*KAN-NEW-03\*\*| \[P1] Fix 4-second Polling Loop DDoS Risk | High (P1) | To Do | Eliminate static short-lived transaction polling timers; implement Exponential Backoff or leverage the WebSocket/FCM push updates structure. |

| \*\*KAN-NEW-04\*\*| \[P1] Implement Parallel RPC Racing \& Health Circuits | High (P1) | To Do | Replace sequential 6-second timeout execution chains with proactive network racing to mitigate dead RPC delays. |



\---



\## 🎨 Epic: UI/UX State, History \& Optimization

Refining visual authenticity, performance parameters, and responsive user states across all viewports.



| Key | Summary | Priority | Status | Description |

| :--- | :--- | :--- | :--- | :--- |

| \*\*KAN-5\*\* | \[P1] Audit remaining ViewModel logic and reusable usecase gaps | High (P1) | In Review | Checking current state management structures for leaks and redundant network calls. |

| \*\*KAN-27\*\* | \[P3] Fix initial transaction detail bottom sheet alignment | Medium (P3) | In Review | Repair layout boundaries and fiat/crypto translation values on the sheet. |

| \*\*KAN-28\*\* | \[P3] Expand transaction status detail with animation to full screen | Medium (P3) | In Review | Implement fluid premium transitions when maximizing transaction information. |

| \*\*KAN-29\*\* | \[P3] Hide main FAB on history and navigation screens | Medium (P3) | In Review | Enforce dynamic visibility for action elements in deeply nested navigation. |

| \*\*KAN-32\*\* | \[P3] Add per-network transaction history selector and refresh state | Medium (P3) | In Review | Deliver top-bar network pills filtering the global transaction database cleanly. |

| \*\*KAN-14\*\* | \[P3] Add shimmer loading state for history screen | Medium (P3) | In Review | Replace generic loading spinners with a premium visual shimmer layout. |

| \*\*KAN-15\*\* | \[P3] Fix empty transaction state in history screen | Medium (P3) | In Review | Clean up edge cases where zero-state layouts fail to display appropriately. |

| \*\*KAN-30\*\* | \[P3] Show history bottom sheet over MainScreen navigation bar | Medium (P3) | To Do | Adjust window-insets and Z-indexing of layout scopes to overlap persistent bars. |

| \*\*KAN-31\*\* | \[P3] Fix first-open history bottom sheet rendering issue | Medium (P3) | Done | Resolved UI freezing when initializing history states on clean app installation. |



\---



\## 🛡️ Epic: Stability, Observability \& Scaling

Ensuring long-term resilience, bug tracking, error taxonomy, and engagement systems.



| Key | Summary | Priority | Status | Description |

| :--- | :--- | :--- | :--- | :--- |

| \*\*KAN-20\*\* | \[P2] Implement global snackbar error handling | Medium (P2) | To Do | Centralize exception handling to display intuitive, graceful notifications to the user. |

| \*\*KAN-21\*\* | \[P2] Define user-facing error taxonomy | Medium (P2) | To Do | Categorize chain errors vs. network failures into non-technical, friendly micro-copy. |

| \*\*KAN-16\*\* | \[P2] Complete settings section | Medium (P2) | To Do | Tie together remaining preferences, licenses, and visual toggles. |

| \*\*KAN-22\*\* | \[P4] Implement referral system for user acquisition | Low (P4) | To Do | Prepare client-side components to capture and process referral invite strings. |

| \*\*KAN-23\*\* | \[P4] Implement quest and vote reward system | Low (P4) | To Do | Frontend architecture to support decentralized governance interfaces and interactive rewards. |

| \*\*KAN-24\*\* | \[P5] Add regression QA checklist for wallet, send, history, and settings | Low (P5) | To Do | Compose an automated testing matrices blueprint for safe multi-chain validation. |

| \*\*KAN-25\*\* | \[P5] Add proxy and gasless observability and debug logs | Low (P5) | To Do | Append diagnostic telemetry tags to capture error parameters without storing personal metadata. |

| \*\*KAN-26\*\* | \[P5] Security review for gasless, referral rewards, and proxy mode | Low (P5) | To Do | External penetration verification pass covering cryptographic inputs and validation paths. |

