# ⚠️ STRICT RULES FOR AI AGENT (NON-NEGOTIABLE)

1. **NO CODE IN CHAT:** Do NOT output any Kotlin code, XML, or diffs in the chat. 
2. **USE FILE TOOLS DIRECTLY:** You MUST use `write_file` or `edit_file` to apply changes directly to the project.
3. **MINIMAL RESPONSE:** After applying files, reply ONLY with a short, bulleted list of the exact file paths you modified. Do not explain the logic.
4. **CLEAN ARCHITECTURE:** 
   - DTOs & Retrofit Interfaces → `data/network/...`
   - Domain Models (sealed classes, business logic) → `domain/model/...`
   - Mappers → `data/mapper/...`
5. **DATA INTEGRITY:** ALL raw monetary values (`valueRaw`, `feeRaw`, `amount`, `nonce`) MUST be typed as `BigInteger` (parsed from JSON String via the registered `BigIntegerStringAdapter`). NEVER use `Long` or `Double`.
6. **ERROR HANDLING:** Branch logic strictly on machine-readable `error.code` (e.g., `RACE_CONDITION_LOCK`, `INSUFFICIENT_GAS_CREDIT`). NEVER parse Farsi `reasonFa` strings for control flow.